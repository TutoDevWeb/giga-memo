<?php

namespace App\Form;

use App\Entity\Categories;
use App\Entity\Faqs;
use App\Model\LayerTypeEnum;
use Doctrine\ORM\EntityRepository; // Ne pas oublier cet import pour le query_builder
use Symfony\Bridge\Doctrine\Form\Type\EntityType;
use Symfony\Component\Form\AbstractType;
use Symfony\Component\Form\Extension\Core\Type\DateIntervalType;
use Symfony\Component\Form\Extension\Core\Type\EnumType;
use Symfony\Component\Form\Extension\Core\Type\TextType;
use Symfony\Component\Form\FormBuilderInterface;
use Symfony\Component\OptionsResolver\OptionsResolver;

class FaqFormType extends AbstractType
{
    public function buildForm(FormBuilderInterface $builder, array $options): void
    {
        // On récupère l'utilisateur passé en option depuis le contrôleur
        $user = $options['user'];

        $builder
            ->add(
                'name',
                TextType::class,
                [
                    'empty_data' => '', // Une chaîne vide ne sera pas transformée en null. Elle reste vide et est filtrée au NotBlank.
                ]
            )
            ->add('category', EntityType::class, [
                'class' => Categories::class,
                'choice_label' => 'name',
                'placeholder' => 'Sélectionnez une catégorie', // Optionnel mais plus propre visuellement
                // On filtre les catégories pour ne proposer que celles de l'utilisateur connecté
                'query_builder' => function (EntityRepository $er) use ($user) {
                    return $er->createQueryBuilder('c')
                        ->where('c.user = :user')
                        ->setParameter('user', $user)
                        ->orderBy('c.name', 'ASC'); // Trié par ordre alphabétique
                },
            ])
            ->add(
                'layerType',
                EnumType::class,
                [
                    'class' => LayerTypeEnum::class,
                ]
            )
            ->add('duration', DateIntervalType::class, [
                'label' => 'Durée prévue',
                // On choisit les unités à afficher
                'with_years' => false,
                'with_months' => false,
                'with_days' => false,
                'with_hours' => false,
                'with_minutes' => true,
                // Le format d'affichage dans le formulaire
                'labels' => [
                    'minutes' => 'Minutes',
                ],
            ]);
    }

    public function configureOptions(OptionsResolver $resolver): void
    {
        $resolver->setDefaults([
            'data_class' => Faqs::class,
            'user' => null, // On définit l'option par défaut
        ]);

        // On rend l'option 'user' obligatoire pour ce formulaire
        $resolver->setRequired('user');
        $resolver->setAllowedTypes('user', ['App\Entity\Users']);
    }
}
